import { View, Pressable, Image, Text, StyleSheet } from 'react-native';
import { useContext } from 'react';
import { usePerfil } from './PerfilContext';
import { MaterialIcons } from '@expo/vector-icons';

export default function HomeScreen({ navigation }) {
  const { setPerfil } = usePerfil();

  const selecionarPerfilAluno = () => {
    setPerfil({ nome: 'Aluno' });
    navigation.navigate('TelaAluno');
  };

  const selecionarPerfilTecnico = () => {
    setPerfil({ nome: 'Técnico' });
    navigation.navigate('TelaTecnico');
  };

  const navigateToChat = () => {
    navigation.navigate('Chat');
  };

  return (
    <View style={styles.container}>
      <View style={styles.perfisContainer}>
        <Pressable onPress={selecionarPerfilAluno} style={styles.perfil}>
          <Image
            style={styles.fotoDePerfil}
            source={{
              uri: 'https://png.pngtree.com/element_our/png/20181129/male-student-icon-png_251938.jpg',
            }}
          />
          <Text style={styles.tPerfil}>Aluno</Text>
        </Pressable>
        <Pressable onPress={selecionarPerfilTecnico} style={styles.perfil}>
          <Image
            style={styles.fotoDePerfil}
            source={{
              uri: 'https://png.pngtree.com/png-vector/20190505/ourmid/pngtree-vector-team-icon-png-image_1023228.jpg',
            }}
          />
          <Text style={styles.tPerfil}>Técnico</Text>
        </Pressable>
      </View>
      <View style={styles.chatContainer}>
        <MaterialIcons
          name="chat"
          size={36}
          color="blue"
          onPress={navigateToChat}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b3f5e1',
  },
  perfisContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tPerfil:{marginTop: 20,
    fontSize: 17,
    fontWeight: 'bold',},
  chatContainer: {
    alignItems: 'flex-end',
    margin: 16,
  },
  fotoDePerfil: {
    height: 100,
    width: 100,
    borderRadius: 100,
  },
  perfil: {
    alignItems: 'center',
    marginHorizontal: 20,
  },
});
