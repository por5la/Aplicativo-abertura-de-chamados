import React, { useState, useContext } from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';
import { usePerfil } from './PerfilContext';
import * as firebase from 'firebase';
import { TelaAluno } from './TelaAlunoScreen';

export default function DetalhesChamadoScreen({ route, navigation }) {
  const [status, setStatus] = useState(route.params.status);
  const { chamados, setChamados } = usePerfil();

  const concluirChamado = () => {
    const item = chamados.find((ite) => {
      ite.id == route.params.chamados.id;
    });
    console.log(item);
    item.status = true;
    setChamados([...chamados]);
  };

  return (
    <View style={styles.containerChamado}>
      <Image style={styles.imagem} source={{ uri: route.params.foto }} />

      <View style={styles.infoContainer}>
        <Text style={styles.nomeChamado}>
          Chamado: {route.params.nomeChamado}
        </Text>
        <Text style={styles.descricaoChamado}>
          Descrição: {route.params.descricaoChamado}
        </Text>
        <Text>{route.params.status ? 'Resolvido' : 'Em aberto'}</Text>
        {status === false && (
          <Pressable style={styles.botao} onPress={concluirChamado}>
            <Text style={styles.botaoTexto}>Concluir Chamado</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  containerChamado: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#b3f5e1',
  },
  infoContainer: {
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    marginBottom: 10,
    marginLeft: 10,
  },
  nomeChamado: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  descricaoChamado: {
    fontSize: 15,
  },
  imagem: {
    marginTop: 25,
    width: '91%',
    height: 200,
    borderRadius: 5,
  },
  botao: {
    width: 300,
    height: 40,
    backgroundColor: '#40b7c3',
    marginVertical: 10,
    borderRadius: 20,
    justifyContent: 'center',
  },
  botaoTexto: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
  },
});
