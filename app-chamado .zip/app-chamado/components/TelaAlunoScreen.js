import React, { useState, useRef, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  Image,
} from 'react-native';
import { usePerfil } from './PerfilContext';
import { Camera } from 'expo-camera';
import * as firebase from 'firebase';

export default function TelaAlunoScreen() {
  const { perfil, chamados, setChamados } = usePerfil();
  const [nomeChamado, setNomeChamado] = useState('');
  const [descricaoChamado, setDescricaoChamado] = useState('');
  const [foto, setFoto] = useState(null);
  const cameraRef = useRef(null);
  const navigation = useNavigation();
  let contador = 0;

  const criarChamado = () => {
    if (nomeChamado && descricaoChamado) {
      firebase
        .database()
        .ref('chamados/')
        .push({ nomeChamado, descricaoChamado, foto })
        .then((data) => {
          console.log('salvou! ', data);
          alert('Chamado criando com SUCESSO');
        })
        .catch((error) => {
          console.log('Erro ao salvar mensagem ', error);
        });
navigation.navigate('Home');
      // setChamados([...chamados, novoChamado]);
      // setNomeChamado('');
      // setDescricaoChamado('');
      // setFoto(null);
      // contador++;
      // navigation.navigate('Home');
      // alert('Chamado criado com SUCESSO!');
    }
  };

  useEffect(() => {
    solicitarPermissao();
  }, []);

  const solicitarPermissao = async () => {
    const { status } = await Camera.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      alert('A permissão da câmera é necessária para tirar fotos.');
    }
  };

  const tirarFoto = async () => {
    if (cameraRef.current) {
      const imagem = await cameraRef.current.takePictureAsync(null);
      setFoto(imagem.uri);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.tAluno}>Nome do Chamado:</Text>
      <TextInput
        style={styles.input}
        value={nomeChamado}
        onChangeText={setNomeChamado}
      />
      <Text style={styles.tAluno}>Descrição do Chamado:</Text>
      <TextInput
        style={styles.input}
        value={descricaoChamado}
        onChangeText={setDescricaoChamado}
      />
      <View style={styles.vCamera}>
        {!foto && (
          <Camera
            ref={cameraRef}
            style={styles.camera}
            type={Camera.Constants.Type.back}
          />
        )}
        {foto && (
          <View>
            <Image source={{ uri: foto }} style={styles.cameraPreview} />
          </View>
        )}
      </View>
      <View style={styles.vBotao}>
        <Pressable style={styles.botao} onPress={tirarFoto}>
          <Text style={styles.botaoTexto}>Tirar Foto</Text>
        </Pressable>
        <Pressable style={styles.botao} onPress={criarChamado}>
          <Text style={styles.botaoTexto}>Criar Chamado</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    backgroundColor: '#b3f5e1',
  },
  tAluno: {
    fontSize: 15,
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 2,
    borderRadius: 5,
    paddingLeft: 12,
    marginBottom: 15,
  },
  vBotao: {
    alignItems: 'center',
  },
  botao: {
    width: 300,
    height: 40,
    backgroundColor: '#40b7c3',
    marginVertical: 10,
    borderRadius: 20,
    justifyContent: 'center',
  },
  botaoTexto: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
  },
  vCamera: {
    alignItems: 'center',
  },
  camera: {
    width: 300,
    height: 300,
    marginBottom: 10,
  },
  cameraPreview: {
    width: 100,
    height: 100,
  },
});
