import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  StyleSheet,
  Image,
  Pressable,
} from 'react-native';
import * as firebase from 'firebase';
import { TelaAluno } from './TelaAlunoScreen';

export default function TelaTecnicoScreen({ navigation }) {
  const [filtro, setFiltro] = useState('');
  const [chamadosFiltrados, setChamadosFiltrados] = useState([]);
  const [chamadas, setCagamadas] = useState([]);

  useEffect(() => {
    carregarMensagensDoFirebase();
  }, []);

  const carregarMensagensDoFirebase = () => {
    firebase
      .database()
      .ref('chamados/')
      .on('value', (snapshot) => {
        const mensagens = [];
        snapshot.forEach((mensagem) => {
          mensagens.unshift(mensagem.val());
        });

        setCagamadas(mensagens.slice());
        atualizarChamadosFiltrados(filtro);
      });
  };

  const atualizarChamadosFiltrados = (filtro) => {
    const chamadosFiltrados = chamadas.filter((item) =>
      item.nomeChamado.toLowerCase().includes(filtro.toLowerCase())
    );
    setChamadosFiltrados(chamadosFiltrados);
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Pesquisar chamados"
        value={filtro}
        onChangeText={(text) => {
          setFiltro(text);
          atualizarChamadosFiltrados(text);
        }}
      />
      <FlatList
        data={chamadosFiltrados.length > 0 ? chamadosFiltrados : chamadas}
        renderItem={({ item }) => (
          <Pressable
            style={styles.chamado}
            onPress={() => {
              navigation.navigate('Detalhes', {
                foto: item.foto,
                nomeChamado: item.nomeChamado,
                descricaoChamado: item.descricaoChamado,
              });
            }}>
            <Image source={{ uri: item.foto }} style={styles.blocofoto} />
            <View>
              <Text>Chamado: {item.nomeChamado}</Text>
              <Text>{item.status ? 'Resolvido' : 'Em aberto'}</Text>
            </View>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b3f5e1',
  },
  input: {
    height: 40,
    borderColor: '#4F4F4F',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
    borderRadius: 5,
  },
  chamado: {
    borderColor: 'gray',
    borderWidth: 2,
    padding: 10,
    marginBottom: 10,
    flexDirection: 'row',
    borderRadius: 5,
  },
  blocofoto: {
    width: 70,
    height: 70,
    marginRight: 10,
  },
});
