// PerfilContext.js
import React, { createContext, useContext, useState } from 'react';

const PerfilContext = createContext();

export function PerfilProvider({ children }) {
  const [perfil, setPerfil] = useState({ nome: '' });
  const [chamados, setChamados] = useState([
    {
      foto: 'https://img.olx.com.br/images/74/745344813841712.webp',
      nome: ' MOUSE QUEBRADO',
      descricao: 'Quebrou o rolamento',
    },
    {
      foto: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS049yBu1HmamxO3wa_VPHiVACeoiVXCTQF6Q&usqp=CAU',
      nome: 'TECLADO NÃO FUNCIONA',
      descricao: 'TECLAS SOLTAS',
    },
  ]);

  return (
    <PerfilContext.Provider
      value={{ perfil, setPerfil, chamados, setChamados }}>
      {children}
    </PerfilContext.Provider>
  );
}

export function usePerfil() {
  const context = useContext(PerfilContext);
  if (!context) {
    throw new Error('usePerfil deve ser usado dentro de um PerfilProvider');
  }
  return context;
}
