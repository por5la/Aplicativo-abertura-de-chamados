const firebaseConfig = {
  apiKey: 'AIzaSyCtE6WJsNBfaiZszqDYUHoA8IPdddXoOZ0',
  authDomain: 'projeto-3449d.firebaseapp.com',
  databaseURL: 'https://projeto-3449d-default-rtdb.firebaseio.com',
  projectId: 'projeto-3449d',
  storageBucket: 'projeto-3449d.appspot.com',
  messagingSenderId: '1035560712861',
  appId: '1:1035560712861:web:cf6121b817065c5236b274',
};

export { firebaseConfig };
