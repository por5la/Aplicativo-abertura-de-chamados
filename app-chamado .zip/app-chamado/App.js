import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './components/HomeScreen';
import TelaAlunoScreen from './components/TelaAlunoScreen';
import TelaTecnicoScreen from './components/TelaTecnicoScreen';
import ChatScreen from './components/ChatScreen';
import DetalhesChamadoScreen from './components/DetalhesChamadoScreen';
import { PerfilProvider } from './components/PerfilContext';

const Stack = createNativeStackNavigator();

import { firebaseConfig } from './config/firebase';

import * as firebase from 'firebase';

try {
  firebase.initializeApp(firebaseConfig);
  console.log('conectou');
} catch (e) {
  console.log('App em carregamento');
}

export default function App() {
  return (
    <NavigationContainer>
      <PerfilProvider>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen
            name="Home"
            component={HomeScreen}
            options={{
              title: 'New Wave Systems',
              headerStyle: {
                backgroundColor: '#00458b',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <Stack.Screen
            name="TelaAluno"
            component={TelaAlunoScreen}
            options={{
              title: 'Criar Chamado',
              headerStyle: {
                backgroundColor: '#00458b',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <Stack.Screen
            name="TelaTecnico"
            component={TelaTecnicoScreen}
            options={{
              title: 'Chamados',
              headerStyle: {
                backgroundColor: '#00458b',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <Stack.Screen
            name="Chat"
            component={ChatScreen}
            options={{
              title: 'CHAT',
              headerStyle: {
                backgroundColor: '#00458b',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
          <Stack.Screen
            name="Detalhes"
            component={DetalhesChamadoScreen}
            options={{
              title: 'Detalhes Chamado',
              headerStyle: {
                backgroundColor: '#00458b',
              },
              headerTintColor: 'white',
              headerTitleStyle: {
                fontWeight: 'bold',
              },
            }}
          />
        </Stack.Navigator>
      </PerfilProvider>
    </NavigationContainer>
  );
}
